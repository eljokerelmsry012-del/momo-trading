-- SINA PRO: safer admin-only account controls and demo-balance administration
-- Run this entire file in Supabase SQL Editor while logged in as project owner.
-- Admin-only functions check public.sina_admins.user_id against auth.uid().
-- This SQL does NOT add a UI by itself; the website must call these RPC functions.

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS demo_balance numeric(14,2) NOT NULL DEFAULT 10000.00;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

-- Ensure admins can be verified only against the existing admin allow-list.
CREATE OR REPLACE FUNCTION public.sina_is_admin()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.sina_admins a WHERE a.user_id = auth.uid());
$$;

CREATE OR REPLACE FUNCTION public.sina_is_account_active()
RETURNS boolean LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v_active boolean;
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  SELECT p.is_active INTO v_active FROM public.profiles p WHERE p.id = auth.uid();
  RETURN COALESCE(v_active, true);
END; $$;

CREATE OR REPLACE FUNCTION public.sina_admin_list_profiles()
RETURNS TABLE(id uuid, username text, demo_balance numeric, is_active boolean)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.sina_is_admin() THEN RAISE EXCEPTION 'admin only'; END IF;
  RETURN QUERY SELECT p.id, p.username::text, p.demo_balance, p.is_active
    FROM public.profiles p ORDER BY p.username NULLS LAST LIMIT 500;
END; $$;

CREATE OR REPLACE FUNCTION public.sina_admin_set_demo_balance(p_user_id uuid, p_balance numeric)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.sina_is_admin() THEN RAISE EXCEPTION 'admin only'; END IF;
  IF p_balance IS NULL OR p_balance < 0 OR p_balance > 1000000000000 THEN RAISE EXCEPTION 'invalid balance'; END IF;
  UPDATE public.profiles SET demo_balance = round(p_balance,2) WHERE id = p_user_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'profile not found'; END IF;
  RETURN true;
END; $$;

CREATE OR REPLACE FUNCTION public.sina_admin_set_account_status(p_user_id uuid, p_is_active boolean)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.sina_is_admin() THEN RAISE EXCEPTION 'admin only'; END IF;
  IF p_user_id = auth.uid() AND p_is_active = false THEN RAISE EXCEPTION 'cannot disable current admin session'; END IF;
  UPDATE public.profiles SET is_active = p_is_active WHERE id = p_user_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'profile not found'; END IF;
  RETURN true;
END; $$;

-- Lock down RPC execution explicitly. Admin RPCs still perform their own admin check.
REVOKE ALL ON FUNCTION public.sina_is_admin() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.sina_is_account_active() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.sina_admin_list_profiles() FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.sina_admin_set_demo_balance(uuid,numeric) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.sina_admin_set_account_status(uuid,boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.sina_is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION public.sina_is_account_active() TO authenticated;
GRANT EXECUTE ON FUNCTION public.sina_admin_list_profiles() TO authenticated;
GRANT EXECUTE ON FUNCTION public.sina_admin_set_demo_balance(uuid,numeric) TO authenticated;
GRANT EXECUTE ON FUNCTION public.sina_admin_set_account_status(uuid,boolean) TO authenticated;

-- Remove the unsafe self-service balance setter from any previous run.
DROP FUNCTION IF EXISTS public.sina_admin_or_self_set_demo_balance(numeric);

-- IMPORTANT: the app still uses client-side demo trading. This SQL does not enable real-money deposits/withdrawals.
